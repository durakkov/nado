#pragma once
#include <windows.h>
#include <vector>
#include <TlHelp32.h>
#include <iostream>

class Memory {
private:
    DWORD processId = 0;
    HANDLE processHandle = NULL;

public:
    Memory(const char* processName) {
        PROCESSENTRY32 entry;
        entry.dwSize = sizeof(PROCESSENTRY32);
        HANDLE snapshot = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, NULL);

        while (Process32Next(snapshot, &entry)) {
            if (!strcmp(processName, entry.szExeFile)) {
                processId = entry.th32ProcessID;
                processHandle = OpenProcess(PROCESS_VM_READ, FALSE, processId);
                break;
            }
        }
        CloseHandle(snapshot);
    }

    ~Memory() { if (processHandle) CloseHandle(processHandle); }

    uintptr_t GetModuleAddress(const char* moduleName) {
        MODULEENTRY32 entry;
        entry.dwSize = sizeof(MODULEENTRY32);
        HANDLE snapshot = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE, processId);
        uintptr_t addr = 0;
        while (Module32Next(snapshot, &entry)) {
            if (!strcmp(moduleName, entry.szModule)) {
                addr = (uintptr_t)entry.modBaseAddr;
                break;
            }
        }
        CloseHandle(snapshot);
        return addr;
    }

    template <typename T>
    T Read(uintptr_t address) {
        T buffer;
        ReadProcessMemory(processHandle, (LPCVOID)address, &buffer, sizeof(T), NULL);
        return buffer;
    }
};