﻿#include <iostream>
#include <thread>
#include "Memory.h"
#include "offsets/offsets.hpp"
#include "offsets/client.dll.hpp"
#include "imgui/imgui.h"

struct Vector3 { float x, y, z; };
struct ViewMatrix { float matrix[4][4]; };

// Математика перевода координат
bool WorldToScreen(Vector3 pos, Vector3& screen, ViewMatrix matrix) {
    float w = matrix.matrix[3][0] * pos.x + matrix.matrix[3][1] * pos.y + matrix.matrix[3][2] * pos.z + matrix.matrix[3][3];
    if (w < 0.01f) return false;

    float invw = 1.0f / w;
    float x = (matrix.matrix[0][0] * pos.x + matrix.matrix[0][1] * pos.y + matrix.matrix[0][2] * pos.z + matrix.matrix[0][3]) * invw;
    float y = (matrix.matrix[1][0] * pos.x + matrix.matrix[1][1] * pos.y + matrix.matrix[1][2] * pos.z + matrix.matrix[1][3]) * invw;

    screen.x = (1920 / 2) + (0.5f * x * 1920 + 0.5f);
    screen.y = (1080 / 2) - (0.5f * y * 1080 + 0.5f);
    return true;
}

void DrawESP(Memory& mem, uintptr_t client) {
    uintptr_t localPlayer = mem.Read<uintptr_t>(client + cs2_dumper::offsets::client_dll::dwLocalPlayerPawn);
    uintptr_t entityList = mem.Read<uintptr_t>(client + cs2_dumper::offsets::client_dll::dwEntityList);
    ViewMatrix vMatrix = mem.Read<ViewMatrix>(client + cs2_dumper::offsets::client_dll::dwViewMatrix);
    int localTeam = mem.Read<int>(localPlayer + cs2_dumper::schemas::client_dll::C_BaseEntity::m_iTeamNum);

    for (int i = 1; i < 64; i++) {
        uintptr_t listEntry = mem.Read<uintptr_t>(entityList + (8 * (i & 0x7FFF) >> 9) + 16);
        if (!listEntry) continue;

        uintptr_t player = mem.Read<uintptr_t>(listEntry + 120 * (i & 0x1FF));
        if (!player || player == localPlayer) continue;

        int health = mem.Read<int>(player + cs2_dumper::schemas::client_dll::C_BaseEntity::m_iHealth);
        int team = mem.Read<int>(player + cs2_dumper::schemas::client_dll::C_BaseEntity::m_iTeamNum);

        if (health <= 0 || team == localTeam) continue;

        Vector3 pos = mem.Read<Vector3>(player + cs2_dumper::schemas::client_dll::C_BasePlayerPawn::m_vOldOrigin);
        Vector3 screenPos;

        if (WorldToScreen(pos, screenPos, vMatrix)) {
            // Рисуем квадрат вокруг врага
            ImGui::GetBackgroundDrawList()->AddRect(
                ImVec2(screenPos.x - 10, screenPos.y - 20), 
                ImVec2(screenPos.x + 10, screenPos.y), 
                ImColor(255, 0, 0)
            );
        }
    }
}