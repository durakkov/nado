﻿#include <iostream>
#include <Windows.h>
#include <TlHelp32.h>
#include <vector>
#include <string>

// Memory helper class for external process interaction
class Memory {
private:
    DWORD processId = 0;
    HANDLE processHandle = nullptr;

public:
    Memory(const std::string& processName) {
        PROCESSENTRY32 entry;
        entry.dwSize = sizeof(PROCESSENTRY32);

        HANDLE snapshot = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, NULL);

        if (snapshot != INVALID_HANDLE_VALUE) {
            while (Process32Next(snapshot, &entry)) {
                if (!processName.compare(entry.szExeFile)) {
                    processId = entry.th32ProcessID;
                    processHandle = OpenProcess(PROCESS_ALL_ACCESS, FALSE, processId);
                    break;
                }
            }
            CloseHandle(snapshot);
        }
    }

    ~Memory() {
        if (processHandle) CloseHandle(processHandle);
    }

    DWORD GetProcessId() const { return processId; }
    HANDLE GetProcessHandle() const { return processHandle; }

    uintptr_t GetModuleAddress(const std::string& moduleName) {
        MODULEENTRY32 entry;
        entry.dwSize = sizeof(MODULEENTRY32);

        HANDLE snapshot = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE | TH32CS_SNAPMODULE32, processId);

        uintptr_t result = 0;
        if (snapshot != INVALID_HANDLE_VALUE) {
            while (Module32Next(snapshot, &entry)) {
                if (!moduleName.compare(entry.szModule)) {
                    result = reinterpret_cast<uintptr_t>(entry.modBaseAddr);
                    break;
                }
            }
            CloseHandle(snapshot);
        }
        return result;
    }

    template <typename T>
    T Read(uintptr_t address) {
        T value;
        ReadProcessMemory(processHandle, reinterpret_cast<LPCVOID>(address), &value, sizeof(T), NULL);
        return value;
    }

    template <typename T>
    void Write(uintptr_t address, const T& value) {
        WriteProcessMemory(processHandle, reinterpret_cast<LPVOID>(address), &value, sizeof(T), NULL);
    }
};

// Common CS2 Offsets (Updated for recent patches - placeholder values)
namespace Offsets {
    // client.dll offsets
    constexpr uintptr_t dwLocalPlayerController = 0x1A14E18; // Placeholder: replace with actual offset
    constexpr uintptr_t dwEntityList = 0x19B6818;           // Placeholder: replace with actual offset
    constexpr uintptr_t dwViewMatrix = 0x1A229E0;           // Placeholder: replace with actual offset

    // Controller offsets
    constexpr uintptr_t m_hPawn = 0x60C;                    // Placeholder: offset from controller to pawn handle

    // Pawn offsets
    constexpr uintptr_t m_iHealth = 0x334;                  // Placeholder: C_BaseEntity -> m_iHealth
    constexpr uintptr_t m_iTeamNum = 0x3C3;                 // Placeholder: C_BaseEntity -> m_iTeamNum
    constexpr uintptr_t m_vOldOrigin = 0x127C;              // Placeholder: C_BasePlayerPawn -> m_vOldOrigin
}

int main() {
    std::cout << "Starting CS2 External Cheat..." << std::endl;

    Memory mem("cs2.exe");

    if (mem.GetProcessId() == 0) {
        std::cout << "Error: Could not find cs2.exe. Make sure the game is running." << std::endl;
        return 1;
    }

    uintptr_t client = mem.GetModuleAddress("client.dll");
    if (client == 0) {
        std::cout << "Error: Could not find client.dll." << std::endl;
        return 1;
    }

    std::cout << "Found cs2.exe (PID: " << mem.GetProcessId() << ")" << std::endl;
    std::cout << "client.dll base: 0x" << std::hex << client << std::dec << std::endl;

    while (true) {
        // Simple loop to read local player information
        uintptr_t localPlayerController = mem.Read<uintptr_t>(client + Offsets::dwLocalPlayerController);
        
        if (localPlayerController) {
            uint32_t pawnHandle = mem.Read<uint32_t>(localPlayerController + Offsets::m_hPawn);
            
            // In CS2, entity list uses a system of lists/chunks.
            // Simplified for demonstration: we'll just read health from the controller if available,
            // or attempt to find the pawn.
            
            // For now, let's just print that we found the local player controller
            // to keep it simple and safe for an initial implementation.
            
            // To find the actual pawn from handle:
            // uintptr_t listEntry = mem.Read<uintptr_t>(mem.Read<uintptr_t>(client + Offsets::dwEntityList) + 0x8 * ((pawnHandle & 0x7FFF) >> 9) + 16);
            // uintptr_t localPawn = mem.Read<uintptr_t>(listEntry + 120 * (pawnHandle & 0x1FF));
            
            // if (localPawn) {
            //     int health = mem.Read<int>(localPawn + Offsets::m_iHealth);
            //     std::cout << "\rLocal Player Health: " << health << "    " << std::flush;
            // }
            
            // For this example, let's just show that we are "running"
            static int count = 0;
            std::cout << "\rCheat active... Reading local controller: 0x" << std::hex << localPlayerController << " [" << std::dec << ++count << "]" << std::flush;
        } else {
            std::cout << "\rWaiting for local player...                     " << std::flush;
        }

        if (GetAsyncKeyState(VK_END)) break; // Exit on END key
        Sleep(100);
    }

    std::cout << "\nExiting..." << std::endl;
    return 0;
}
